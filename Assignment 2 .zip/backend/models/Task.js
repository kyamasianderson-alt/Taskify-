
const mongoose=require('mongoose');
module.exports=mongoose.model('Task',new mongoose.Schema({
title:{type:String,required:true},
description:String,
status:{type:String,default:'Pending'}
},{timestamps:true}));
