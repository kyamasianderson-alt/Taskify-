
require('dotenv').config();
const express=require('express');const cors=require('cors');const mongoose=require('mongoose');
const app=express();app.use(cors());app.use(express.json());
mongoose.connect(process.env.MONGO_URI);
app.use('/api/tasks',require('./routes/tasks'));
app.listen(process.env.PORT||5000);
