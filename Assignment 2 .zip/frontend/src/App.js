
import {useEffect,useState} from 'react';import axios from 'axios';
export default function App(){
const [tasks,setTasks]=useState([]),[title,setTitle]=useState('');
const load=()=>axios.get('http://localhost:5000/api/tasks').then(r=>setTasks(r.data));
useEffect(load,[]);
const add=async()=>{if(!title.trim())return;await axios.post('http://localhost:5000/api/tasks',{title});setTitle('');load();};
const del=async(id)=>{await axios.delete('http://localhost:5000/api/tasks/'+id);load();};
return <div className="c"><h1>Taskify</h1><input value={title} onChange={e=>setTitle(e.target.value)} placeholder="Task"/><button onClick={add}>Add</button><ul>{tasks.map(t=><li key={t._id}>{t.title}<button onClick={()=>del(t._id)}>Delete</button></li>)}</ul></div>
}
